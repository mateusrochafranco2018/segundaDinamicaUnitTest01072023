class TestPhonebook:

    def test_add_1(self):
        assert 1 == 2

    def test_add_2(self):
        assert "1" == 1

    def test_add_3(self):
        assert "F" == "f"

    def test_add_4(self):
        assert False

    def test_add_5(self):
        assert True
