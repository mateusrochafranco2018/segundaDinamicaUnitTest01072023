from unittest import TestCase


class TestPhonebook(TestCase):

    def test_add(self):
        self.assertEqual(True, True)
